using LogicLibrary;
using Pryamolineynost;
using PryamolineynostWF.Views;
using PryamolineynostWF.Views.Collimator;

namespace PryamolineynostWF;

internal static class Program
{
    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    [STAThread]
    private static void Main()
    {
        // To customize application configuration such as set high DPI settings or default font,
        // see https://aka.ms/applicationconfiguration.
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        ApplicationConfiguration.Initialize();
        //var deviceChooserForm = new DeviceChooseForm();
        //Application.Run(deviceChooserForm);

        Application.Run(new CollimatorMainForm(Enums.CollimatorType.ACU05, DateTime.Now, "SomeActNumber1231231"));

    }
}